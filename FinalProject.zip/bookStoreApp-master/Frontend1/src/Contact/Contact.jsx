
import Navbar from "../components/Navbar";

import Footer from "../components/Footer";
import React from "react";
import './contact.css'
import { useState } from "react";
function Contact(){
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    const handleSubmit = (e) => {
        e.preventDefault();
            setIsModalOpen(true)
    }

    
    const closeModal = () => {
        setIsModalOpen(false) 
    }
    return (
        <>
        <Navbar/>
        
        <form onSubmit={handleSubmit} className="cnt">
            <legend className="formHeading"> Contact Us</legend>
            <div className="form-group">
            <label htmlFor="" className="lab">Full Name</label>
            <input type="text" placeholder="Enter Your Name"  required/>
            </div>
            

            <div className="form-group">
            <label htmlFor="" className="lab">Email</label>
            <input type="email" placeholder="Enter Your Email" required/>
            </div>
            

            <div className="form-group">
            <label htmlFor="" className="lab">Phone</label>
            <input type="tel" placeholder="Enter Your Phone Number" required/>
            </div>
            
            <div className="form-group">
            <label htmlFor="" className="lab">Message</label>
            <textarea name="" id="" className="msg" placeholder="Type Your Message Here..." required></textarea>
            </div>
            <button className="button" >Submit</button>
        </form>

        {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
                        <p className="text-lg font-semibold text-green-600">
                            Your response has been submitted!
                        </p>
                        <button
                            onClick={closeModal}
                            className="mt-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}
        <Footer/>
        </>

    );
}

export default Contact;
