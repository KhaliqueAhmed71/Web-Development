import React, { useEffect, useState } from "react";
import Cards from "./Cards";
import axios from "axios";
import { Link } from "react-router-dom";
function Course() {
  const [book, setBook] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
    
    const handleSubmit = (e) => {
        e.preventDefault();
            setIsModalOpen(true)
    }

    
    const closeModal = () => {
        setIsModalOpen(false) 
    }
  useEffect(() => {
    const getBook = async () => {
      try {
        const res = await axios.get("http://localhost:4001/book");
        console.log(res.data);
        setBook(res.data);
      } catch (error) {
        console.log(error);
      }
    };
    getBook();
  }, []);
  return (
    <>
      <div className=" max-w-screen-2xl container mx-auto md:px-20 px-4" >
        <div className="pt-28 items-center justify-center text-center">
         
          <h1 className="pt-12" >
          "Education is the passport to the future, for tomorrow belongs to those who prepare for it today."
       <br /> – Malcolm X


          </h1>
          <Link to="/">
            
          </Link>
        </div>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-4">
          {book.map((item) => (
            <Cards key={item.id} item={item} />
          ))}
        </div>
      </div>

      {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
                        <p className="text-lg font-semibold text-green-600">
                            Your response has been submitted!
                        </p>
                        <button
                            onClick={closeModal}
                            className="mt-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}
    </>
  );
}

export default Course;
