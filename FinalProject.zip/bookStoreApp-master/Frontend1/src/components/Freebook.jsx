import React, { useEffect, useState } from "react";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

import axios from "axios";

import Cards from "./Cards";
function Freebook() {
 
  return (
    <>
      <div className=" max-w-screen-2xl container mx-auto md:px-20 px-4">
        <div>
          <h1 className="font-semibold text-xl pb-2">Easy Shopping Experience:</h1>
          <p style={{marginBottom:"25px"}}>
          With a user-friendly interface and secure checkout, buying books online has never been easier</p>
        </div>

      </div>
    </>
  );
}
export default Freebook;

 