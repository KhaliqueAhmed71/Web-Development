import Footer from '../components/Footer';
import Navbar from '../components/Navbar';
import './About.css'
import react from 'react'

function About() {
    return (
        <>
        <Navbar/>
        <div className='aboutUs'>
            <h1 className='about-heading'>About Us</h1>
            <h2 className='h2'> Welcome to our Bookstore!</h2>
            <p className='pre'>


                At our boostore, we are passionate about making books accessible to everyone. Our mission is to provide a wide range <br />
                of books at discounted prices, ensuring that every reader can find their next favorite book without breaking the bank.

                <h2 className='h2'>What We Offer:</h2>

                <h3 className='h3'>Extensive Collection:</h3> From fiction to non-fiction, comics to academic books, we have something for every reader.
                <br /> <br />
                <h3 className='h3'>Extensive Collection:</h3> Enjoy exclusive discounts on our entire range of books.
                <br /> <br />
                <h3 className='h3'>Customer Support:</h3> Our dedicated team is always ready to assist you. Feel free to reach out through our Contact Us page. <br />
                We believe that reading inspires creativity, enhances knowledge, and opens up a world of endless possibilities. Whether <br />
                you're an avid reader or just starting your reading journey, we’re here to ensure you have the best experience
            </p>
            </div>
            <Footer/>
        </>

    );
}

export default About;